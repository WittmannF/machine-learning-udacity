The following Python libraries are required to run this project:

- numpy
- pandas
- matplotlib
- re
- wordcloud (amueller.github.io/word_cloud/)
- nltk
- sklearn
